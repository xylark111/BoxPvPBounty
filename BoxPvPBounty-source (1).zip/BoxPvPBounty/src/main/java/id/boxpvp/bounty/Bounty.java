package id.boxpvp.bounty;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public final class Bounty {

    private final UUID id;
    private final UUID target;
    private final String targetName;
    private final UUID creator;
    private final String creatorName;
    private final List<ItemStack> rewards;
    private final long createdAt;

    public Bounty(UUID id, UUID target, String targetName, UUID creator, String creatorName,
                  List<ItemStack> rewards, long createdAt) {
        this.id = id;
        this.target = target;
        this.targetName = targetName;
        this.creator = creator;
        this.creatorName = creatorName;
        this.createdAt = createdAt;

        List<ItemStack> copy = new ArrayList<>();
        if (rewards != null) {
            for (ItemStack item : rewards) {
                if (item != null && !item.getType().isAir() && item.getAmount() > 0) {
                    copy.add(item.clone());
                }
            }
        }
        this.rewards = Collections.unmodifiableList(copy);
    }

    public UUID getId() {
        return id;
    }

    public UUID getTarget() {
        return target;
    }

    public String getTargetName() {
        return targetName;
    }

    public UUID getCreator() {
        return creator;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public List<ItemStack> getRewards() {
        return rewards;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public int getTotalItems() {
        int total = 0;
        for (ItemStack item : rewards) {
            total += item.getAmount();
        }
        return total;
    }

    public int getStackCount() {
        return rewards.size();
    }
}
