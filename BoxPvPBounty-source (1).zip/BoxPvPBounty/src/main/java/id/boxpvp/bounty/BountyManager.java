package id.boxpvp.bounty;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Data bounty disimpan di ConcurrentHashMap (key = ID bounty).
 * remove() bersifat atomik: hanya satu pemanggil yang bisa berhasil menghapus sebuah bounty,
 * sehingga reward tidak mungkin dibayarkan/dikembalikan dua kali.
 * File ditulis async dari snapshot string (digabung dalam jeda 2 detik agar tidak menulis berulang-ulang).
 */
public final class BountyManager {

    private final BountyPlugin plugin;
    private final File dataFile;
    private final Map<UUID, Bounty> bounties = new ConcurrentHashMap<>();
    private final Object ioLock = new Object();

    private boolean saveScheduled;
    private long version;
    private long lastWritten;

    public BountyManager(BountyPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "bounties.yml");
    }

    // ------------------------------------------------------------------ load

    public void load() {
        bounties.clear();

        if (!dataFile.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root = config.getConfigurationSection("bounties");

        if (root == null) {
            return;
        }

        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);

            if (section == null) {
                continue;
            }

            try {
                UUID id = UUID.fromString(key);
                UUID target = UUID.fromString(section.getString("target", ""));
                UUID creator = UUID.fromString(section.getString("creator", ""));
                String targetName = section.getString("target-name", "Unknown");
                String creatorName = section.getString("creator-name", "Unknown");
                long createdAt = section.getLong("created-at", 0L);

                List<ItemStack> rewards = new ArrayList<>();
                for (Object object : section.getList("rewards", new ArrayList<>())) {
                    if (object instanceof ItemStack item) {
                        rewards.add(item);
                    }
                }

                Bounty bounty = new Bounty(id, target, targetName, creator, creatorName, rewards, createdAt);

                if (!bounty.getRewards().isEmpty()) {
                    bounties.put(id, bounty);
                }
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Data bounty tidak valid dilewati: " + key);
            }
        }
    }

    // ------------------------------------------------------------------ operasi data (main thread)

    public void addBounty(Bounty bounty) {
        bounties.put(bounty.getId(), bounty);
        markDirty();
    }

    /** @return true hanya jika bounty masih ada dan berhasil dihapus oleh pemanggil ini. */
    public boolean removeBounty(Bounty bounty) {
        boolean removed = bounties.remove(bounty.getId()) != null;
        if (removed) {
            markDirty();
        }
        return removed;
    }

    /** Hapus semua bounty untuk target dan kembalikan yang berhasil dihapus (dipakai saat target terbunuh). */
    public List<Bounty> removeAllForTarget(UUID target) {
        List<Bounty> removed = new ArrayList<>();

        for (Bounty bounty : sortedBounties()) {
            if (bounty.getTarget().equals(target) && bounties.remove(bounty.getId()) != null) {
                removed.add(bounty);
            }
        }

        if (!removed.isEmpty()) {
            markDirty();
        }
        return removed;
    }

    public boolean hasBounty(UUID target) {
        for (Bounty bounty : bounties.values()) {
            if (bounty.getTarget().equals(target)) {
                return true;
            }
        }
        return false;
    }

    public List<Bounty> getBountiesForTarget(UUID target) {
        List<Bounty> result = new ArrayList<>();
        for (Bounty bounty : sortedBounties()) {
            if (bounty.getTarget().equals(target)) {
                result.add(bounty);
            }
        }
        return result;
    }

    public List<Bounty> getBountiesByCreator(UUID creator) {
        List<Bounty> result = new ArrayList<>();
        for (Bounty bounty : sortedBounties()) {
            if (bounty.getCreator().equals(creator)) {
                result.add(bounty);
            }
        }
        return result;
    }

    /** Target -> daftar bounty-nya, urut dari bounty tertua. */
    public Map<UUID, List<Bounty>> getGroupedByTarget() {
        Map<UUID, List<Bounty>> grouped = new LinkedHashMap<>();
        for (Bounty bounty : sortedBounties()) {
            grouped.computeIfAbsent(bounty.getTarget(), k -> new ArrayList<>()).add(bounty);
        }
        return grouped;
    }

    private List<Bounty> sortedBounties() {
        List<Bounty> list = new ArrayList<>(bounties.values());
        list.sort(Comparator.comparingLong(Bounty::getCreatedAt).thenComparing(b -> b.getId().toString()));
        return list;
    }

    // ------------------------------------------------------------------ penyimpanan

    private void markDirty() {
        if (saveScheduled) {
            return;
        }
        saveScheduled = true;

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            saveScheduled = false;
            final String data = serialize();
            final long currentVersion = ++version;
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> write(data, currentVersion));
        }, 40L);
    }

    /** Simpan langsung (hanya dipakai saat plugin dimatikan). */
    public void saveNow() {
        write(serialize(), ++version);
    }

    private String serialize() {
        YamlConfiguration config = new YamlConfiguration();

        for (Bounty bounty : bounties.values()) {
            String path = "bounties." + bounty.getId();
            config.set(path + ".target", bounty.getTarget().toString());
            config.set(path + ".target-name", bounty.getTargetName());
            config.set(path + ".creator", bounty.getCreator().toString());
            config.set(path + ".creator-name", bounty.getCreatorName());
            config.set(path + ".created-at", bounty.getCreatedAt());
            config.set(path + ".rewards", new ArrayList<>(bounty.getRewards()));
        }

        return config.saveToString();
    }

    private void write(String data, long dataVersion) {
        synchronized (ioLock) {
            if (dataVersion < lastWritten) {
                return; // data yang lebih baru sudah tertulis
            }
            lastWritten = dataVersion;

            try {
                Path target = dataFile.toPath();
                Files.createDirectories(target.getParent());
                Path temp = target.resolveSibling("bounties.yml.tmp");
                Files.writeString(temp, data, StandardCharsets.UTF_8);

                try {
                    Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException exception) {
                    Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException exception) {
                plugin.getLogger().log(Level.SEVERE, "Gagal menyimpan bounties.yml", exception);
            }
        }
    }
}
