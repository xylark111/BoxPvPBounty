package id.boxpvp.bounty;

import id.boxpvp.bounty.gui.PluginGUI;
import id.boxpvp.bounty.listener.DeathListener;
import id.boxpvp.bounty.listener.GuiListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class BountyPlugin extends JavaPlugin {

    private final Map<UUID, PluginGUI> openGuis = new HashMap<>();
    private BountyManager bountyManager;

    @Override
    public void onEnable() {
        bountyManager = new BountyManager(this);
        bountyManager.load();

        getCommand("bounty").setExecutor(new BountyCommand(this));
        getCommand("mybounty").setExecutor(new MyBountyCommand(this));

        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);
        Bukkit.getPluginManager().registerEvents(new DeathListener(this), this);

        getLogger().info("BoxPvPBounty aktif.");
    }

    @Override
    public void onDisable() {
        // Kembalikan item yang masih tertahan di GUI yang sedang terbuka (tidak ada item hilang saat restart/reload)
        for (PluginGUI gui : new ArrayList<>(openGuis.values())) {
            gui.onClose();
        }
        openGuis.clear();

        if (bountyManager != null) {
            bountyManager.saveNow();
        }
    }

    public BountyManager getBountyManager() {
        return bountyManager;
    }

    public void registerGui(UUID playerId, PluginGUI gui) {
        openGuis.put(playerId, gui);
    }

    public PluginGUI unregisterGui(UUID playerId) {
        return openGuis.remove(playerId);
    }

    public boolean hasOpenGui(UUID playerId) {
        return openGuis.containsKey(playerId);
    }
}
