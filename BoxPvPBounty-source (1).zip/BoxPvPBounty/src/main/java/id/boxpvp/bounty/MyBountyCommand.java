package id.boxpvp.bounty;

import id.boxpvp.bounty.gui.MyBountyGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MyBountyCommand implements CommandExecutor {

    private final BountyPlugin plugin;

    public MyBountyCommand(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cPerintah ini hanya untuk pemain.");
            return true;
        }

        new MyBountyGUI(plugin, player, 0).open();
        return true;
    }
}
