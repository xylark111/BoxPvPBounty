package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class MyBountyGUI extends PluginGUI {

    private static final String TITLE = "§8Bounty Milikmu";
    private static final int PAGE_SIZE = 45;

    private final int page;
    private final List<Bounty> shownBounties = new ArrayList<>();

    public MyBountyGUI(BountyPlugin plugin, Player player) {
        this(plugin, player, 0);
    }

    public MyBountyGUI(BountyPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = Math.max(0, page);
    }

    @Override
    protected void build() {
        createInventory(TITLE, 54);

        List<Bounty> mine = plugin.getBountyManager().getBountiesByCreator(player.getUniqueId());

        int start = page * PAGE_SIZE;
        int end = Math.min(mine.size(), start + PAGE_SIZE);

        for (int index = start; index < end; index++) {
            Bounty bounty = mine.get(index);

            List<String> lore = new ArrayList<>();
            lore.add("§7Target: §f" + bounty.getTargetName());
            lore.add("§7Total item reward: §f" + bounty.getTotalItems());
            lore.add("§7Jumlah stack reward: §f" + bounty.getStackCount());
            lore.add("");
            lore.add("§cKlik untuk membatalkan bounty.");

            inventory.setItem(index - start, head(Bukkit.getOfflinePlayer(bounty.getTarget()),
                    "§e§l" + bounty.getTargetName(), lore));
            shownBounties.add(bounty);
        }

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 45, 53);

        if (page > 0) {
            inventory.setItem(45, button(Material.ARROW, "§e§lSEBELUMNYA", "§7Halaman " + page));
        }

        inventory.setItem(49, button(Material.ARROW, "§e§lBACK", "§7Kembali ke menu bounty."));

        if (end < mine.size()) {
            inventory.setItem(53, button(Material.ARROW, "§e§lBERIKUTNYA", "§7Halaman " + (page + 2)));
        }

        if (mine.isEmpty()) {
            inventory.setItem(22, button(Material.BARRIER, "§cKamu belum membuat bounty",
                    "§7Gunakan §f/bounty add §7untuk membuat bounty."));
        }
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();

        if (slot == 45 && page > 0) {
            new MyBountyGUI(plugin, player, page - 1).open();
            return;
        }

        if (slot == 49) {
            new BountyMenuGUI(plugin, player, 0).open();
            return;
        }

        if (slot == 53 && clicked != null && clicked.getType() == Material.ARROW) {
            new MyBountyGUI(plugin, player, page + 1).open();
            return;
        }

        if (slot >= 0 && slot < shownBounties.size()) {
            new ConfirmCancelGUI(plugin, player, shownBounties.get(slot)).open();
        }
    }
}
