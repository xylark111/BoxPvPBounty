package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract class PluginGUI implements InventoryHolder {

    protected final BountyPlugin plugin;
    protected final Player player;
    protected Inventory inventory;

    /** Jika true, GUI ini sudah selesai: semua klik dibatalkan dan item tidak akan dikembalikan lagi. */
    protected boolean done;

    protected PluginGUI(BountyPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    /** Isi inventory GUI. */
    protected abstract void build();

    /** Dipanggil hanya untuk klik di inventory atas (slot GUI). */
    public abstract void handleClick(InventoryClickEvent event);

    public void open() {
        build();
        player.openInventory(inventory);
        plugin.registerGui(player.getUniqueId(), this);
    }

    /** true hanya untuk GUI yang memperbolehkan pemain menaruh item (RewardGUI). */
    public boolean acceptsItems() {
        return false;
    }

    /** Dipanggil saat GUI ditutup / pemain keluar / plugin dimatikan. Harus aman dipanggil berulang. */
    public void onClose() {
    }

    public boolean isDone() {
        return done;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    protected void createInventory(String title, int size) {
        inventory = Bukkit.createInventory(this, size, title);
    }

    protected void fillRow(ItemStack item, int start, int end) {
        for (int slot = start; slot <= end; slot++) {
            inventory.setItem(slot, item);
        }
    }

    // ------------------------------------------------------------------ helper item

    protected static ItemStack filler(Material material) {
        return button(material, " ");
    }

    protected static ItemStack button(Material material, String name, String... lore) {
        return button(material, name, Arrays.asList(lore));
    }

    protected static ItemStack button(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);

        return item;
    }

    protected static ItemStack head(OfflinePlayer owner, String name, List<String> lore) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) item.getItemMeta();

        meta.setOwningPlayer(owner);
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);

        return item;
    }

    /** Beri item ke pemain; sisa yang tidak muat di-drop di lokasinya (tidak ada item yang hilang). */
    public static void giveItems(Player target, Collection<ItemStack> items) {
        for (ItemStack item : items) {
            if (item == null || item.getType().isAir()) {
                continue;
            }

            Map<Integer, ItemStack> leftover = target.getInventory().addItem(item.clone());
            for (ItemStack rest : leftover.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), rest);
            }
        }
    }
}
