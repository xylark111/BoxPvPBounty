package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class RewardGUI extends PluginGUI {

    /** Slot 0-44 = area reward. Slot 45-53 = baris kontrol (terkunci). */
    public static final int REWARD_START = 0;
    public static final int REWARD_END = 44;
    public static final int CONTROL_START = 45;

    private static final int CANCEL_SLOT = 45;
    private static final int BACK_SLOT = 49;
    private static final int SAVE_SLOT = 53;

    private final UUID target;
    private final String targetName;

    public RewardGUI(BountyPlugin plugin, Player player, UUID target, String targetName) {
        super(plugin, player);
        this.target = target;
        this.targetName = targetName;
    }

    @Override
    protected void build() {
        createInventory("§8Masukkan Reward untuk §e" + targetName, 54);

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 46, 48);
        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 50, 52);

        inventory.setItem(CANCEL_SLOT, button(Material.RED_STAINED_GLASS_PANE, "§c§lCANCEL",
                "§7Batalkan dan ambil kembali item."));

        inventory.setItem(BACK_SLOT, button(Material.ARROW, "§e§lBACK",
                "§7Kembali memilih pemain.", "§7Item dikembalikan ke inventorymu."));

        inventory.setItem(SAVE_SLOT, button(Material.LIME_STAINED_GLASS_PANE, "§a§lSAVE",
                "§7Simpan reward dan lanjut", "§7ke konfirmasi bounty."));
    }

    @Override
    public boolean acceptsItems() {
        return true;
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        if (done) {
            return;
        }

        int slot = event.getRawSlot();

        if (slot == CANCEL_SLOT) {
            returnItems();
            player.closeInventory();
            player.sendMessage("§cBounty dibatalkan. Item dikembalikan.");
            return;
        }

        if (slot == BACK_SLOT) {
            returnItems();
            new PlayerSelectGUI(plugin, player, 0).open();
            return;
        }

        if (slot == SAVE_SLOT) {
            if (!hasRewards()) {
                player.sendMessage("§cMasukkan minimal 1 item sebagai reward.");
                return;
            }

            // Tandai selesai SEBELUM mengosongkan area, supaya penutupan GUI tidak mengembalikan item lagi
            done = true;
            List<ItemStack> rewards = takeRewards();
            new ConfirmGUI(plugin, player, target, targetName, rewards).open();
        }
    }

    @Override
    public void onClose() {
        returnItems();
    }

    /** Kembalikan semua item di area reward ke pemain (aman dipanggil berulang). */
    private void returnItems() {
        if (done) {
            return;
        }
        done = true;
        giveItems(player, takeRewards());
    }

    private boolean hasRewards() {
        for (int slot = REWARD_START; slot <= REWARD_END; slot++) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && !item.getType().isAir()) {
                return true;
            }
        }
        return false;
    }

    /** Ambil semua item dari area reward dan kosongkan area tersebut. */
    private List<ItemStack> takeRewards() {
        List<ItemStack> rewards = new ArrayList<>();

        for (int slot = REWARD_START; slot <= REWARD_END; slot++) {
            ItemStack item = inventory.getItem(slot);

            if (item != null && !item.getType().isAir()) {
                rewards.add(item.clone());
            }
            inventory.setItem(slot, null);
        }

        return rewards;
    }
}
