package id.boxpvp.bounty.listener;

import id.boxpvp.bounty.BountyPlugin;
import id.boxpvp.bounty.gui.PluginGUI;
import id.boxpvp.bounty.gui.RewardGUI;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class GuiListener implements Listener {

    private final BountyPlugin plugin;

    public GuiListener(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Filter murah dulu: hanya pemain yang sedang membuka GUI plugin ini yang diperiksa lebih lanjut
        if (!plugin.hasOpenGui(player.getUniqueId())) {
            return;
        }

        Inventory top = event.getView().getTopInventory();

        if (!(top.getHolder() instanceof PluginGUI gui)) {
            return;
        }

        // GUI sudah selesai -> kunci total
        if (gui.isDone()) {
            event.setCancelled(true);
            return;
        }

        int size = top.getSize();
        int rawSlot = event.getRawSlot();

        // Menu biasa: semua klik dibatalkan; hanya klik pada inventory atas yang diteruskan
        if (!(gui instanceof RewardGUI)) {
            event.setCancelled(true);

            if (rawSlot >= 0 && rawSlot < size && event.getClickedInventory() == top) {
                gui.handleClick(event);
            }
            return;
        }

        // ---------------- RewardGUI: slot 0-44 + inventory pemain boleh dipakai normal ----------------

        // Double-click bisa menarik item filler/tombol ke cursor, creative bisa memunculkan item -> blokir
        if (event.getClick() == ClickType.CREATIVE || event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true);
            return;
        }

        // Baris kontrol (CANCEL, filler, BACK, SAVE) terkunci
        if (rawSlot >= RewardGUI.CONTROL_START && rawSlot < size) {
            event.setCancelled(true);
            gui.handleClick(event);
            return;
        }

        // Shift-click dari inventory pemain: pindahkan manual hanya ke slot kosong area reward
        if (event.getClick().isShiftClick() && rawSlot >= size) {
            event.setCancelled(true);

            ItemStack current = event.getCurrentItem();
            if (current == null || current.getType().isAir()) {
                return;
            }

            for (int slot = RewardGUI.REWARD_START; slot <= RewardGUI.REWARD_END; slot++) {
                ItemStack existing = top.getItem(slot);

                if (existing == null || existing.getType().isAir()) {
                    top.setItem(slot, current.clone());
                    event.setCurrentItem(null);
                    return;
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (!plugin.hasOpenGui(player.getUniqueId())) {
            return;
        }

        Inventory top = event.getView().getTopInventory();

        if (!(top.getHolder() instanceof PluginGUI gui)) {
            return;
        }

        if (gui.isDone() || !(gui instanceof RewardGUI)) {
            event.setCancelled(true);
            return;
        }

        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot >= RewardGUI.CONTROL_START && rawSlot < top.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        UUID id = event.getPlayer().getUniqueId();

        if (!plugin.hasOpenGui(id)) {
            return;
        }

        if (event.getInventory().getHolder() instanceof PluginGUI gui) {
            plugin.unregisterGui(id);
            gui.onClose();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        PluginGUI gui = plugin.unregisterGui(event.getPlayer().getUniqueId());

        if (gui != null) {
            gui.onClose();
        }
    }
}
