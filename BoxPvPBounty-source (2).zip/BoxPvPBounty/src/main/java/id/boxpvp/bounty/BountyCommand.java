package id.boxpvp.bounty;

import id.boxpvp.bounty.gui.BountyMenuGUI;
import id.boxpvp.bounty.gui.PlayerSelectGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class BountyCommand implements CommandExecutor {

    private final BountyPlugin plugin;

    public BountyCommand(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cPerintah ini hanya untuk pemain.");
            return true;
        }

        plugin.fx().open(player);

        if (args.length > 0 && args[0].equalsIgnoreCase("add")) {
            new PlayerSelectGUI(plugin, player, 0).open();
            return true;
        }

        new BountyMenuGUI(plugin, player, 0).open();
        return true;
    }
}
