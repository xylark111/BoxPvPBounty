package id.boxpvp.bounty;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

/** Efek suara dan action bar. Semua suara bisa dimatikan lewat config.yml (sounds: false). */
public final class Fx {

    private final BountyPlugin plugin;

    public Fx(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    private void play(Player player, Sound sound, float volume, float pitch) {
        if (player == null || !player.isOnline()) {
            return;
        }
        if (!plugin.getConfig().getBoolean("sounds", true)) {
            return;
        }
        player.playSound(player.getLocation(), sound, volume, pitch);
    }

    /** Klik tombol biasa / pindah halaman. */
    public void click(Player player) {
        play(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.3f);
    }

    /** Menaruh item ke area reward. */
    public void place(Player player) {
        play(player, Sound.ENTITY_ITEM_FRAME_ADD_ITEM, 0.7f, 1.2f);
    }

    /** Membuka menu dari command. */
    public void open(Player player) {
        play(player, Sound.ITEM_BOOK_PAGE_TURN, 0.8f, 1.0f);
    }

    /** Aksi berhasil (bounty dibuat, bounty dibatalkan). */
    public void success(Player player) {
        play(player, Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
    }

    /** Aksi ditolak / error. */
    public void error(Player player) {
        play(player, Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
    }

    /** Membatalkan sesuatu. */
    public void cancel(Player player) {
        play(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.8f);
    }

    /** Item dikembalikan ke inventory. */
    public void refund(Player player) {
        play(player, Sound.ENTITY_ITEM_PICKUP, 0.8f, 1.0f);
    }

    /** Killer berhasil klaim bounty. */
    public void claim(Player player) {
        play(player, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        play(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    /** Peringatan untuk target yang baru dipasangi bounty. */
    public void alert(Player player) {
        play(player, Sound.BLOCK_BELL_USE, 1.0f, 0.7f);
    }

    public void actionBar(Player player, String message) {
        if (player == null || !player.isOnline()) {
            return;
        }
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(message));
    }
}
