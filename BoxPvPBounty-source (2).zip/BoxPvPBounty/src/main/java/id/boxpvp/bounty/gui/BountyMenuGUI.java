package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class BountyMenuGUI extends PluginGUI {

    private static final int PAGE_SIZE = 45;

    private final int page;
    private final List<UUID> shownTargets = new ArrayList<>();

    public BountyMenuGUI(BountyPlugin plugin, Player player) {
        this(plugin, player, 0);
    }

    public BountyMenuGUI(BountyPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = Math.max(0, page);
    }

    @Override
    protected void build() {
        Map<UUID, List<Bounty>> grouped = plugin.getBountyManager().getGroupedByTarget();
        List<UUID> targets = new ArrayList<>(grouped.keySet());

        createInventory("§8§lBOXPVP BOUNTY §7(" + targets.size() + ")", 54);

        int start = page * PAGE_SIZE;
        int end = Math.min(targets.size(), start + PAGE_SIZE);

        for (int index = start; index < end; index++) {
            UUID target = targets.get(index);
            List<Bounty> bounties = grouped.get(target);

            int totalItems = 0;
            int totalStacks = 0;
            for (Bounty bounty : bounties) {
                totalItems += bounty.getTotalItems();
                totalStacks += bounty.getStackCount();
            }

            boolean online = Bukkit.getPlayer(target) != null;

            List<String> lore = new ArrayList<>();
            lore.add("§7Status: " + (online ? "§aOnline" : "§cOffline"));
            lore.add("§7Bounty aktif: §f" + bounties.size());
            lore.add("§7Total item reward: §f" + totalItems + " §8(" + totalStacks + " stack)");
            lore.add("");
            lore.add("§eKlik kiri §7- info bounty");
            lore.add("§eKlik kanan §7- lihat reward");

            inventory.setItem(index - start, head(Bukkit.getOfflinePlayer(target),
                    "§c§l" + bounties.get(0).getTargetName(), lore));
            shownTargets.add(target);
        }

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 45, 53);

        if (page > 0) {
            inventory.setItem(45, button(Material.ARROW, "§e§l« SEBELUMNYA", "§7Halaman " + page));
        }

        inventory.setItem(47, button(Material.BOOK, "§b§lMY BOUNTY",
                "§7Lihat bounty yang kamu buat.", "§7Klik untuk membuka."));

        inventory.setItem(49, button(Material.EMERALD, "§a§lTAMBAH BOUNTY",
                "§7Pilih pemain online", "§7yang ingin kamu beri bounty."));

        inventory.setItem(51, button(Material.OAK_SIGN, "§6§lCARA KERJA",
                "§71. Klik §aTAMBAH BOUNTY §7lalu pilih pemain.",
                "§72. Masukkan item sebagai reward.",
                "§73. Siapa pun yang membunuh target",
                "§7   mendapat semua reward-nya.",
                "",
                "§7Bounty bisa dibatalkan lewat §f/mybounty§7."));

        if (end < targets.size()) {
            inventory.setItem(53, button(Material.ARROW, "§e§lBERIKUTNYA »", "§7Halaman " + (page + 2)));
        }

        if (targets.isEmpty()) {
            inventory.setItem(22, button(Material.BARRIER, "§cBelum ada bounty aktif",
                    "§7Klik tombol hijau di bawah", "§7untuk membuat bounty."));
        }
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();

        if (slot == 45 && page > 0) {
            new BountyMenuGUI(plugin, player, page - 1).open();
            return;
        }

        if (slot == 47) {
            new MyBountyGUI(plugin, player, 0).open();
            return;
        }

        if (slot == 49) {
            new PlayerSelectGUI(plugin, player, 0).open();
            return;
        }

        if (slot == 53 && clicked != null && clicked.getType() == Material.ARROW) {
            new BountyMenuGUI(plugin, player, page + 1).open();
            return;
        }

        if (slot >= 0 && slot < shownTargets.size()) {
            UUID target = shownTargets.get(slot);
            List<Bounty> bounties = plugin.getBountyManager().getBountiesForTarget(target);

            if (bounties.isEmpty()) {
                player.sendMessage("§cBounty untuk pemain ini sudah tidak aktif.");
                plugin.fx().error(player);
                return;
            }

            // Klik kanan: lihat semua reward
            if (event.isRightClick()) {
                new RewardPreviewGUI(plugin, player, target, page).open();
                return;
            }

            // Klik kiri: info di chat
            int totalItems = 0;
            for (Bounty bounty : bounties) {
                totalItems += bounty.getTotalItems();
            }

            player.sendMessage("§8§m                                        ");
            player.sendMessage("§6§lBOUNTY §c" + bounties.get(0).getTargetName());
            player.sendMessage("§7Jumlah bounty aktif: §f" + bounties.size());
            player.sendMessage("§7Total item reward: §f" + totalItems);
            player.sendMessage("§7Bunuh pemain ini untuk mendapatkan semua reward!");
            player.sendMessage("§8§m                                        ");
        }
    }
}
