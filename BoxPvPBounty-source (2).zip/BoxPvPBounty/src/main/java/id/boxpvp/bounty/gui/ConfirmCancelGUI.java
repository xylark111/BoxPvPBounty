package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

public final class ConfirmCancelGUI extends PluginGUI {

    private static final int CANCEL_SLOT = 11;
    private static final int TARGET_SLOT = 13;
    private static final int CONFIRM_SLOT = 15;

    private final Bounty bounty;

    public ConfirmCancelGUI(BountyPlugin plugin, Player player, Bounty bounty) {
        super(plugin, player);
        this.bounty = bounty;
    }

    @Override
    protected void build() {
        createInventory("§8Batalkan Bounty: §e" + bounty.getTargetName(), 27);

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 0, 26);

        List<String> lore = new ArrayList<>();
        lore.add("§7Reward yang akan dikembalikan:");
        lore.add("§f" + bounty.getTotalItems() + " item §7(" + bounty.getStackCount() + " stack)");

        inventory.setItem(TARGET_SLOT, head(Bukkit.getOfflinePlayer(bounty.getTarget()),
                "§e§l" + bounty.getTargetName(), lore));

        inventory.setItem(CANCEL_SLOT, button(Material.RED_STAINED_GLASS_PANE, "§c§lCANCEL",
                "§7Kembali ke daftar bounty-mu."));

        inventory.setItem(CONFIRM_SLOT, button(Material.LIME_STAINED_GLASS_PANE, "§a§lCONFIRM",
                "§7Batalkan bounty ini dan", "§7ambil kembali semua reward."));
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        if (done) {
            return;
        }

        int slot = event.getRawSlot();

        if (slot == CANCEL_SLOT) {
            new MyBountyGUI(plugin, player, 0).open();
            return;
        }

        if (slot == CONFIRM_SLOT) {
            done = true;

            // removeBounty() atomik: false berarti bounty sudah diklaim/dibatalkan -> tidak ada refund ganda
            if (plugin.getBountyManager().removeBounty(bounty)) {
                giveItems(player, bounty.getRewards());
                player.sendMessage("§aBounty untuk §f" + bounty.getTargetName() + " §adibatalkan.");
                player.sendMessage("§aReward dikembalikan ke inventorymu.");
                plugin.fx().success(player);
                plugin.fx().refund(player);
                plugin.fx().actionBar(player, "§aBounty dibatalkan, reward dikembalikan.");
            } else {
                player.sendMessage("§cBounty ini sudah tidak aktif.");
                plugin.fx().error(player);
            }

            player.closeInventory();
        }
    }
}
