package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public final class ConfirmGUI extends PluginGUI {

    private static final int CANCEL_SLOT = 45;
    private static final int CONFIRM_SLOT = 53;

    private final UUID target;
    private final String targetName;
    private final List<ItemStack> rewards;

    public ConfirmGUI(BountyPlugin plugin, Player player, UUID target, String targetName, List<ItemStack> rewards) {
        super(plugin, player);
        this.target = target;
        this.targetName = targetName;
        this.rewards = rewards;
    }

    @Override
    protected void build() {
        createInventory("§8Konfirmasi Bounty: §e" + targetName, 54);

        int slot = 0;
        for (ItemStack reward : rewards) {
            if (slot > 44) {
                break;
            }
            inventory.setItem(slot, reward.clone());
            slot++;
        }

        fillRow(filler(Material.BLACK_STAINED_GLASS_PANE), 45, 53);

        inventory.setItem(CANCEL_SLOT, button(Material.RED_STAINED_GLASS_PANE, "§c§lCANCEL",
                "§7Batalkan bounty dan", "§7ambil kembali reward."));

        inventory.setItem(CONFIRM_SLOT, button(Material.LIME_STAINED_GLASS_PANE, "§a§lCONFIRM",
                "§7Buat bounty untuk §f" + targetName + "§7.",
                "§7Reward ditahan sampai target terbunuh",
                "§7atau kamu membatalkannya di /mybounty."));
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        if (done) {
            return;
        }

        int slot = event.getRawSlot();

        if (slot == CANCEL_SLOT) {
            done = true;
            giveItems(player, rewards);
            player.closeInventory();
            player.sendMessage("§cBounty dibatalkan. Reward dikembalikan.");
            plugin.fx().cancel(player);
            plugin.fx().refund(player);
            return;
        }

        if (slot == CONFIRM_SLOT) {
            done = true;

            Bounty bounty = new Bounty(
                    UUID.randomUUID(),
                    target,
                    targetName,
                    player.getUniqueId(),
                    player.getName(),
                    rewards,
                    System.currentTimeMillis()
            );

            plugin.getBountyManager().addBounty(bounty);

            player.closeInventory();
            player.sendMessage("§aBounty untuk §f" + targetName + " §aberhasil dibuat.");
            player.sendMessage("§7Total reward: §f" + bounty.getTotalItems() + " §7item.");
            plugin.fx().success(player);
            plugin.fx().actionBar(player, "§aBounty untuk §f" + targetName + " §aberhasil dibuat!");

            if (plugin.getConfig().getBoolean("broadcast-on-create", true)) {
                Bukkit.broadcastMessage("§6§lBOUNTY §8» §e" + player.getName()
                        + " §7memasang bounty untuk §c" + targetName
                        + " §8(§f" + bounty.getTotalItems() + " §7item§8)");
            }

            Player targetPlayer = Bukkit.getPlayer(target);
            if (targetPlayer != null && plugin.getConfig().getBoolean("notify-target", true)) {
                targetPlayer.sendMessage("§c§lBOUNTY §8» §e" + player.getName()
                        + " §7memasang bounty atas kepalamu! §8(§f" + bounty.getTotalItems() + " §7item§8)");
                targetPlayer.sendTitle("§c§lBOUNTY",
                        "§7Kepalamu dihargai §f" + bounty.getTotalItems() + " §7item", 5, 50, 10);
                plugin.fx().alert(targetPlayer);
            }
        }
    }

    @Override
    public void onClose() {
        // Ditutup tanpa memilih CONFIRM/CANCEL (ESC, disconnect, restart): reward WAJIB dikembalikan
        if (done) {
            return;
        }
        done = true;
        giveItems(player, rewards);
    }
}
