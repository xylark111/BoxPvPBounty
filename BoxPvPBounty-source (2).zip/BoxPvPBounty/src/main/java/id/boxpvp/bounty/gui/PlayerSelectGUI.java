package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public final class PlayerSelectGUI extends PluginGUI {

    private static final String TITLE = "§8Pilih Pemain untuk Bounty";
    private static final int PAGE_SIZE = 45;

    private final int page;
    private final List<UUID> shownPlayers = new ArrayList<>();

    public PlayerSelectGUI(BountyPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = Math.max(0, page);
    }

    @Override
    protected void build() {
        createInventory(TITLE, 54);

        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        online.removeIf(other -> other.getUniqueId().equals(player.getUniqueId()));
        online.sort(Comparator.comparing(other -> other.getName().toLowerCase()));

        int start = page * PAGE_SIZE;
        int end = Math.min(online.size(), start + PAGE_SIZE);

        for (int index = start; index < end; index++) {
            Player target = online.get(index);

            List<String> lore = new ArrayList<>();
            if (plugin.getBountyManager().hasBounty(target.getUniqueId())) {
                lore.add("§6Pemain ini sudah punya bounty aktif.");
            }
            lore.add("§7Klik untuk memilih pemain ini.");
            lore.add("");
            lore.add("§eSelanjutnya kamu memasukkan item reward.");

            inventory.setItem(index - start, head(target, "§e" + target.getName(), lore));
            shownPlayers.add(target.getUniqueId());
        }

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 45, 53);

        if (page > 0) {
            inventory.setItem(45, button(Material.ARROW, "§e§l« SEBELUMNYA", "§7Halaman " + page));
        }

        inventory.setItem(49, button(Material.BARRIER, "§c§lKEMBALI", "§7Kembali ke menu bounty."));

        if (end < online.size()) {
            inventory.setItem(53, button(Material.ARROW, "§e§lBERIKUTNYA »", "§7Halaman " + (page + 2)));
        }

        if (online.isEmpty()) {
            inventory.setItem(22, button(Material.BARRIER, "§cTidak ada pemain lain yang online"));
        }
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();

        if (slot == 45 && page > 0) {
            new PlayerSelectGUI(plugin, player, page - 1).open();
            return;
        }

        if (slot == 49) {
            new BountyMenuGUI(plugin, player, 0).open();
            return;
        }

        if (slot == 53 && clicked != null && clicked.getType() == Material.ARROW) {
            new PlayerSelectGUI(plugin, player, page + 1).open();
            return;
        }

        if (slot >= 0 && slot < shownPlayers.size()) {
            UUID targetId = shownPlayers.get(slot);

            if (targetId.equals(player.getUniqueId())) {
                player.sendMessage("§cKamu tidak bisa memberi bounty untuk dirimu sendiri.");
                plugin.fx().error(player);
                return;
            }

            // Validasi ulang: target harus masih online
            Player target = Bukkit.getPlayer(targetId);
            if (target == null || !target.isOnline()) {
                player.sendMessage("§cPemain tersebut sudah offline.");
                plugin.fx().error(player);
                return;
            }

            new RewardGUI(plugin, player, target.getUniqueId(), target.getName()).open();
        }
    }
}
