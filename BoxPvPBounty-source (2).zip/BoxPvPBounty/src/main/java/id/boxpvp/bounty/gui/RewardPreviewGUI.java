package id.boxpvp.bounty.gui;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

/** Hanya untuk melihat reward milik satu target. Item tidak bisa diambil. */
public final class RewardPreviewGUI extends PluginGUI {

    private final UUID target;
    private final int backPage;

    public RewardPreviewGUI(BountyPlugin plugin, Player player, UUID target, int backPage) {
        super(plugin, player);
        this.target = target;
        this.backPage = backPage;
    }

    @Override
    protected void build() {
        List<Bounty> bounties = plugin.getBountyManager().getBountiesForTarget(target);
        String name = bounties.isEmpty() ? "?" : bounties.get(0).getTargetName();

        createInventory("§8Reward Bounty: §c" + name, 54);

        int slot = 0;
        int hidden = 0;

        for (Bounty bounty : bounties) {
            for (ItemStack reward : bounty.getRewards()) {
                if (slot < 45) {
                    inventory.setItem(slot++, reward.clone());
                } else {
                    hidden++;
                }
            }
        }

        fillRow(filler(Material.GRAY_STAINED_GLASS_PANE), 45, 53);

        inventory.setItem(49, button(Material.ARROW, "§e§lBACK",
                hidden > 0 ? "§7+" + hidden + " stack lagi tidak ditampilkan" : "§7Kembali ke daftar bounty."));

        if (bounties.isEmpty()) {
            inventory.setItem(22, button(Material.BARRIER, "§cBounty ini sudah tidak aktif"));
        }
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        if (event.getRawSlot() == 49) {
            new BountyMenuGUI(plugin, player, backPage).open();
        }
    }
}
