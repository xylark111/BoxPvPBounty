package id.boxpvp.bounty.listener;

import id.boxpvp.bounty.Bounty;
import id.boxpvp.bounty.BountyPlugin;
import id.boxpvp.bounty.gui.PluginGUI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.List;

public final class DeathListener implements Listener {

    private final BountyPlugin plugin;

    public DeathListener(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) {
            return;
        }

        if (!plugin.getBountyManager().hasBounty(victim.getUniqueId())) {
            return;
        }

        // Hapus dulu (atomik), baru bayar -> bounty tidak mungkin diklaim dua kali
        List<Bounty> claimed = plugin.getBountyManager().removeAllForTarget(victim.getUniqueId());

        if (claimed.isEmpty()) {
            return;
        }

        int totalItems = 0;

        for (Bounty bounty : claimed) {
            PluginGUI.giveItems(killer, bounty.getRewards());
            totalItems += bounty.getTotalItems();
        }

        Bukkit.broadcastMessage("§6§lBOUNTY CLAIMED §8» §e" + killer.getName()
                + " §7telah membunuh §f" + victim.getName()
                + " §7dan mendapatkan §f" + totalItems + " §7item reward!");

        killer.sendTitle("§6§lBOUNTY CLAIMED", "§e+" + totalItems + " item reward", 5, 50, 15);
        plugin.fx().claim(killer);
        plugin.fx().actionBar(killer, "§6Bounty §c" + victim.getName() + " §6berhasil diklaim!");
    }
}
